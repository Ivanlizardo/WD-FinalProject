#include <iostream>
#include <queue>
#include <iomanip>
#include <cstdlib>
#include <fstream>

#define RESET "\033[0m"
#define GREEN "\033[32m"
#define RED "\033[31m"
#define CYAN "\033[36m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define BRIGHT_YELLOW "\033[1;33m"

using namespace std;

char verticalLine = 186;
char horizontalLine = 205;
char upperRightCorner = 187;
char upperLeftCorner = 201;
char lowerRightCorner = 188;
char lowerLeftCorner = 200;
char threeRightCorner = 185;
char threeLeftCorner = 204;
char centerCross = 206;
char threeDownCorner = 203;
char threeUpCorner = 202;

// Node for linked list of PCs
struct PCNode {
    int id;
    string renterName;
    bool isRented;
    int timeRent;
    PCNode* next;

    PCNode(int id) {
        this->id = id;
        renterName = "";
        isRented = false;
        timeRent = 0;
        next = NULL;
    }
};

// Struct for rent history records
struct RentRecord {
    int pcID;
    string renterName;
    int timeRent;
    RentRecord* next;

    RentRecord(int id, string name, int time) {
        pcID = id;
        renterName = name;
        timeRent = time;
        next = NULL;
    }
};

// Struct for waiting list customers
struct Customer {
    string name;
    int timeRequest;
};

// Class for managing the list of PCs
class PCList {
private:
    PCNode* head;
    RentRecord* rentHistoryHead;
    char verticalLine = 186;
	char horizontalLine = 205;
	char upperRightCorner = 187;
	char upperLeftCorner = 201;
	char lowerRightCorner = 188;
	char lowerLeftCorner = 200;
	char threeRightCorner = 185;
	char threeLeftCorner = 204;
	char centerCross = 206;
	char threeDownCorner = 203;
	char threeUpCorner = 202;
	char centerCrossValue = 206;

public:
    PCList() {
        head = NULL;
        rentHistoryHead = NULL;
        // Create 15 PCs
        for (int i = 1; i <= 15; i++) {
            addPC(i);
        }
    }

    void addPC(int id) {
        PCNode* newNode = new PCNode(id);
        if (!head) head = newNode;
        else {
            PCNode* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    // Display ALL PCs with status - ALWAYS CALLED!
    void displayGrid() {
    	int lenght = 100 - 2;
        for(int i = 0; i < 3; i++){
        	if (i == 0){
        		for(int j = 0; j < lenght; j++){
        			if(j == 0){ 
		        		cout << verticalLine << upperLeftCorner;
					}
					else if(j == 13 || j == 50 || j == 74){
						cout << threeDownCorner;
					}
					else if(j == 97){
						cout << upperRightCorner << verticalLine;
					}
					else{
						cout << horizontalLine;
					}
				}
			}
			else if(i == 1){
				cout << endl;
				for(int j = 0; j < lenght; j++){
					if(j == 0 || j == 71){
						cout << verticalLine << verticalLine;
						cout << (j == 0 ? " ID" : "");
					}else if(j == 10){
						cout << verticalLine << " Renter";
					}
					else if(j == 40){
						cout << verticalLine << " Time(hr)";
					}
					else if(j == 55){
						cout << verticalLine << " Status";
					}	
					else if (j > 80){
						cout << "";
					}
					else{
						cout << " ";
					}
				}
			}
			else{
				cout << endl;
        		for(int j = 0; j < lenght; j++){
        			if(j == 0){ 
		        		cout << verticalLine << threeLeftCorner;
					}
					else if(j == 13 || j == 50 || j == 74){
						cout << centerCrossValue;
					}
					else if(j == 97){
						cout << threeRightCorner << verticalLine;
					}
					else{
						cout << horizontalLine;
					}
				}
			}
        	
		}
		
		cout << endl;
        PCNode* temp = head;
        int flag = 0;

        while (temp) {
        	cout << verticalLine << verticalLine << " " << left << setw(11) << temp->id << setfill(' ') << verticalLine
        		 << " " << left << setw(35) << (temp->isRented ? temp->renterName : "-") << setfill(' ') << verticalLine
        		 << " " << left << setw(22) << (temp->isRented ? temp->timeRent : 0) << setfill(' ') << verticalLine;    		 
				 if (temp->isRented){
				 	cout << " " << left << RED << setw(21) << "Rented" << RESET;
				 }else{
				 	cout << " " << left  << GREEN << setw(21) << "Available" << RESET;
				 }			 
			cout << setfill(' ') << verticalLine << verticalLine;
        	cout << endl;
        	
        	for(int j = 0; j < lenght; j++){
    			if(j == 0){ 
	        		cout << verticalLine << (flag == 14 ? lowerLeftCorner : threeLeftCorner);
				}
				else if(j == 13 || j == 50 || j == 74){
					cout << (flag == 14 ? threeUpCorner : centerCrossValue);
				}
				else if(j == 97){
					cout << (flag == 14 ? lowerRightCorner : threeRightCorner) << verticalLine; 
				}
				else{
					cout << horizontalLine;
				}
			}		
			cout << endl;
			flag++;
            temp = temp->next;
            
        }
        for(int i = 0; i < lenght + 2; i++){
			if(i == 0){
				cout << lowerLeftCorner;
			}
			else if(i == lenght + 1){
				cout << lowerRightCorner;
			}
			else{
				cout << horizontalLine;
			}
		}
		cout << endl;
    }

    void addInformation(int id, string renterName, int timeRent) {
        PCNode* pc = findPC(id);
        if (!pc) {
            cout << "PC #" << id << " not found.\n";
            return;
        }
        if (pc->isRented) {
            cout << "PC #" << id << " is already rented.\n";
            return;
        }
        pc->renterName = renterName;
        pc->timeRent = timeRent;
        pc->isRented = true;
        cout << "PC #" << id << " rented to " << renterName << " for " << timeRent << " hour(s).\n";

        // Add to rent history
        RentRecord* newRecord = new RentRecord(id, renterName, timeRent);
        newRecord->next = rentHistoryHead;
        rentHistoryHead = newRecord;
    }

    void extendTime(int id, int extraHours) {
        PCNode* pc = findPC(id);
        if (!pc) {
            cout << "PC #" << id << " not found.\n";
            return;
        }
        if (!pc->isRented) {
            cout << "PC #" << id << " is not currently rented.\n";
            return;
        }
        pc->timeRent += extraHours;
        cout << "Extended time for PC #" << id << " by " << extraHours << " hour(s). Total time: " << pc->timeRent << " hour(s).\n";
    }

    void releasePC(int id) {
        PCNode* pc = findPC(id);
        if (!pc) {
            cout << "PC #" << id << " not found.\n";
            return;
        }
        if (!pc->isRented) {
            cout << "PC #" << id << " is not currently rented.\n";
            return;
        }
        pc->renterName = "";
        pc->timeRent = 0;
        pc->isRented = false;
        cout << "PC #" << id << " has been released and is now available.\n";
    }

    void searchPC(int id) {
    	system("cls");
    	header();
    	
        PCNode* pc = findPC(id);
        if (!pc) {
            cout << "PC #" << id << " not found.\n";
            return;
        }
        
        cout << verticalLine << GREEN << left << setw(98) << " Search Result " << RESET << setfill(' ') << verticalLine << endl;
        cout << right << verticalLine << setw(99) << verticalLine << endl;
        cout << verticalLine << left << " PC # " << setw(92) << pc->id << setfill(' ') << verticalLine << endl;
        cout << verticalLine << left << " Status: ";
        
        if(pc->isRented){
        	cout << RED << setw(89) << "Rented" << RESET << setfill(' ') << verticalLine << endl;
		}
		else{
			cout << GREEN << setw(89) << "Available" << RESET << setfill(' ') << verticalLine << endl;
		}
        	
		if (pc->isRented) {
            cout << left << verticalLine << " Renter: " << setw(89) << pc->renterName << setfill(' ') << verticalLine << endl;
            cout << verticalLine << " Time Rent: " << left << setw(2) << pc->timeRent << setfill(' ') << setw(84) << " hour(s)" << setfill(' ') << verticalLine << endl;
        }
        
                
        
        for(int i = 0; i < 100; i++){
        	if(i == 0){
        		cout << lowerLeftCorner; 	 
			}
			else if(i == 99){
				cout << lowerRightCorner; 
			}
			else{
				cout << horizontalLine;
			}
		}
        cout << endl << endl;
    }
	
    void showAvailable() {
    	header();
        cout << verticalLine << GREEN << " Available Computers Only " << setw(76) << RESET << verticalLine << endl;
        cout << right << verticalLine << setw(99) << verticalLine << endl;
        
		PCNode* temp = head;
        bool found = false;
        while (temp) {
            if (!temp->isRented) {
                cout << verticalLine  << " PC #"<< left << setw(3) << temp->id << setfill(' ') << setw(90) << "is available." << setfill(' ') << verticalLine << endl;
                found = true;
            }
            temp = temp->next;
        }
        if (!found) cout << "No available computers.\n";
        for(int i = 0; i < 100; i++){
        	if(i == 0){
        		cout << lowerLeftCorner; 	 
			}
			else if(i == 99){
				cout << lowerRightCorner; 
			}
			else{
				cout << horizontalLine;
			}
		}
        cout << endl << endl;
    }

    void showActive() {
    	system("cls");
    	header();
        cout << right << verticalLine << RED << " Active User Computers Only" << RESET << setw(72) << verticalLine << endl;
        cout << verticalLine << setw(99) << verticalLine << endl;
        
        PCNode* temp = head;
        bool found = false;
        while (temp) {
            if (temp->isRented) {
                cout << left  << setw(1) << verticalLine << setw(6) << " PC #" << setfill(' ') << setw(3) << temp->id << setfill(' ') << setw(10) << "rented to" << setfill(' ')
					 << setw(10) << temp->renterName  << setfill(' ') << setw(10) << "for" << setfill(' ') << setw(3) << temp->timeRent<< setfill(' ') << setw(56)  << "hour(s)." << setfill(' ') << verticalLine << endl;
                found = true;
            }
            temp = temp->next;
        }
        if (!found) cout << verticalLine << " No active rentals." << setw(80) << verticalLine << endl;
        for(int i = 0; i < 100; i++){
        	if(i == 0){
        		cout << lowerLeftCorner; 	 
			}
			else if(i == 99){
				cout << lowerRightCorner; 
			}
			else{
				cout << horizontalLine;
			}
		}
        cout << endl << endl;
    }

    void showRentHistory() {
    	system("cls");
    	header();
        cout << right << verticalLine<< " All Renters for the Day " << setw(74) << verticalLine << endl;
        cout << verticalLine << setw(99) << verticalLine << endl;
        
        RentRecord* temp = rentHistoryHead;
        if (!temp) {
        	cout << right << verticalLine << " No rentals yet." << setw(83) << verticalLine << endl;
        	for(int i = 0; i < 100; i++){
	        	if(i == 0){
	        		cout << lowerLeftCorner; 	 
				}
				else if(i == 99){
					cout << lowerRightCorner; 
				}
				else{
					cout << horizontalLine;
				}
			}
            cout << endl << endl;
            return;
        }
        for(int i = 0; i < 100; i++){
        	if(i == 0 || i == 99){
        		cout << verticalLine;
			}
			else if(i == 1){
				cout << upperLeftCorner;
			}
			else if(i == 98){
				cout << upperRightCorner;
			}
			else if (i == 21 || i == 76){
				cout << threeDownCorner;
			}
			else{
				cout << horizontalLine;
			}
		}
       	cout << endl;
        cout << verticalLine << verticalLine << " PC#" << setw(16) 
			 << verticalLine << " Name" << setw(50)
			 << verticalLine << " Hours" << setw(16) << verticalLine << verticalLine << endl;
			 
		for(int i = 0; i < 100; i++){
        	if(i == 0 || i == 99){
        		cout << verticalLine;
			}
			else if(i == 1){
				cout << threeLeftCorner;
			}
			else if(i == 98){
				cout << threeRightCorner;
			}
			else if (i == 21 || i == 76){
				cout << centerCrossValue;
			}
			else{
				cout << horizontalLine;
			}
		}
		cout << endl;
        while (temp) {
        	
            cout << verticalLine << verticalLine << " " << left << setw(18) << temp->pcID << setfill(' ') << verticalLine
            	 << " " << setw(53) << temp->renterName << setfill(' ') << verticalLine
            	 << " " << setw(20) << temp->timeRent << setfill(' ') << verticalLine << verticalLine << endl;
                 
            temp = temp->next;
        }
        for(int i = 0; i < 100; i++){
        	if(i == 0 || i == 99){
        		cout << verticalLine;
			}
			else if(i == 1){
				cout << lowerLeftCorner;
			}
			else if(i == 98){
				cout << lowerRightCorner;
			}
			else if (i == 21 || i == 76){
				cout << threeUpCorner;
			}
			else{
				cout << horizontalLine;
			}
		}
		cout << endl;
        for(int i = 0; i < 100; i++){
        	if(i == 0){
        		cout << lowerLeftCorner; 	 
			}
			else if(i == 99){
				cout << lowerRightCorner; 
			}
			else{
				cout << horizontalLine;
			}
		}
        cout << endl << endl;
    }
    
	//DESIGN
	void header(){
	    int length = 100;
	
	    for (int i = 0; i < 3; i++) {
	        for (int j = 0; j < length; j++) {
	
	            if (i == 0) {  // TOP border
	                if (j == 0)
	                    cout << upperLeftCorner;
	                else if (j == length - 1)
	                    cout << upperRightCorner;
	                else
	                    cout << horizontalLine;
	            }
	
	            else if (i == 1) {
				    if (j == 0)
				        cout << verticalLine;
				    else if (j == length - 1)
				        cout << verticalLine;
				    else {
				        string label = "AbeleOps Database";
				        int labelLength = label.length();
				        int startPos = (length - 2 - labelLength) / 2 + 1;
				
				        if (j >= startPos && j < startPos + labelLength)
				            cout << BRIGHT_YELLOW << label[j - startPos] << RESET;
				        else
				            cout << " ";
				    }
				}
	
	            else if (i == 2) {  // BOTTOM border
	                if (j == 0)
	                    cout << threeLeftCorner;
	                else if (j == length - 1)
	                    cout << threeRightCorner;
	                else
	                    cout << horizontalLine;
	            }
	        }
	        cout << endl;
	    }
	}
	
	// Save All PCs 
	void saveAllPCsAsHTML() {
	    ofstream out("AllPCs.html");
	    out << "<!DOCTYPE html>\n";
	    out << "<html lang=\"en\">\n";
	    out << "<head>\n";
	    out << "  <meta charset=\"UTF-8\" />\n";
	    out << "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n";
	    out << "  <title>All PCs</title>\n";
	    out << "  <style>\n";
	    out << "    @import url('https://fonts.googleapis.com/css2?family=monsterrat:wght@400;700&display=swap');\n";
	    out << "    * { box-sizing: border-box; margin: 0; padding: 0; color: white; font-family: monsterrat, sans-serif; }\n";
	    out << "    html { background-color: #333; }\n";
	    out << "    table { border-collapse: collapse; width: 80%; margin: 20px auto; }\n";
	    out << "    header { display: flex; align-items: center; background-color: #000; padding: 0rem 2rem; gap: 2rem; }\n";
	    out << "    header a { text-decoration: none; color: white; }\n";
	    out << "    header img { aspect-ratio: 1/1; height: 7rem; }\n";
	    out << "    #img { margin-right: auto; }\n";
	    out << "    #btn1, #btn2, #btn3, #btn4 { background-color: #423fff; padding: 0.5rem 1rem; border-radius: 0.5rem; }\n";
	    out << "    #btn1:hover, #btn2:hover, #btn4:hover { background-color: #5250ff; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
	    out << "    #btn3 { background-color: #ff3838; }\n";
	    out << "    #btn3:hover { background-color: #ff4848; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
	    out << "    .container { display: flex; justify-content: center; padding: 2rem 0 1rem 0; }\n";
	    out << "    .container h2 { color: #ff3838; }\n";
	    out << "    th, td { border: 1px solid #000; padding: 8px; text-align: left; }\n";
	    out << "    th { background-color: #423fff; }\n";
	    out << "  </style>\n";
	    out << "</head>\n";
	    out << "<body>\n";
	    out << "  <header>\n";
	    out << "    <div id=\"img\">\n";
	    out << "      <a href=\"AllPCs.html\"><img src=\"logoOps.png\" alt=\"Logo\" /></a>\n";
	    out << "    </div>\n";
	    out << "    <div id=\"btn1\"><a href=\"AvailablePCs.html\">Available PC</a></div>\n";
	    out << "    <div id=\"btn2\"><a href=\"RentHistory.html\">Rent History</a></div>\n";
	    out << "    <div id=\"btn4\"><a href=\"Waitlist.html\">Waitlist</a></div>\n";
	    out << "    <div id=\"btn3\"><a href=\"members.html\">Members</a></div>\n";
	    out << "  </header>\n";
	    out << "  <div class=\"container\"><h2>All Personal Computers</h2></div>\n";
	    out << "  <table>\n";
	    out << "    <tr>\n";
	    out << "      <th>ID</th>\n";
	    out << "      <th>Renter</th>\n";
	    out << "      <th>Time(hr)</th>\n";
	    out << "      <th>Status</th>\n";
	    out << "    </tr>\n";
	
	    // Dynamically add each PC row
	    PCNode* temp = head;
	    while (temp) {
	        out << "    <tr>\n";
	        out << "      <td>" << temp->id << "</td>\n";
	        out << "      <td>" << (temp->isRented ? temp->renterName : "-") << "</td>\n";
	        out << "      <td>" << (temp->isRented ? temp->timeRent : 0) << "</td>\n";
	        out << "      <td>" << (temp->isRented ? "Rented" : "Available") << "</td>\n";
	        out << "    </tr>\n";
	        temp = temp->next;
	    }
	
	    out << "  </table>\n";
	    out << "</body>\n";
	    out << "</html>\n";
	
	    out.close();
	}

	
	// Save Available PCs
	void saveAvailablePCsAsHTML() {
	    ofstream out("AvailablePCs.html");
	    out << "<!DOCTYPE html>\n";
	    out << "<html lang=\"en\">\n";
	    out << "<head>\n";
	    out << "  <meta charset=\"UTF-8\" />\n";
	    out << "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n";
	    out << "  <title>Available PCs</title>\n";
	    out << "  <style>\n";
	    out << "    @import url('https://fonts.googleapis.com/css2?family=monsterrat:wght@400;700&display=swap');\n";
	    out << "    * { box-sizing: border-box; margin: 0; padding: 0; color: white; font-family: monsterrat, sans-serif; }\n";
	    out << "    html { background-color: #333; }\n";
	    out << "    table { border-collapse: collapse; width: 80%; margin: 20px auto; }\n";
	    out << "    header { display: flex; align-items: center; background-color: #000; padding: 0rem 2rem; gap: 2rem; }\n";
	    out << "    header a { text-decoration: none; color: white; }\n";
	    out << "    header img { aspect-ratio: 1/1; height: 7rem; }\n";
	    out << "    #img { margin-right: auto; }\n";
	    out << "    #btn1, #btn2, #btn3, #btn4 { background-color: #423fff; padding: 0.5rem 1rem; border-radius: 0.5rem; }\n";
	    out << "    #btn1:hover, #btn2:hover, #btn4:hover { background-color: #5250ff; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
	    out << "    #btn3 { background-color: #ff3838; }\n";
	    out << "    #btn3:hover { background-color: #ff4848; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
	    out << "    .container { display: flex; justify-content: center; padding: 2rem 0 1rem 0; }\n";
	    out << "    .container h2 { color: #ff3838; }\n";
	    out << "    th, td { border: 1px solid #000; padding: 8px; text-align: left; }\n";
	    out << "    th { background-color: #423fff; }\n";
	    out << "  </style>\n";
	    out << "</head>\n";
	    out << "<body>\n";
	    out << "  <header>\n";
	    out << "    <div id=\"img\">\n";
	    out << "      <a href=\"AllPCs.html\"><img src=\"logoOps.png\" alt=\"Logo\" /></a>\n";
	    out << "    </div>\n";
	    out << "    <div id=\"btn1\"><a href=\"AvailablePCs.html\">Available PC</a></div>\n";
	    out << "    <div id=\"btn2\"><a href=\"RentHistory.html\">Rent History</a></div>\n";
	    out << "    <div id=\"btn4\"><a href=\"Waitlist.html\">Waitlist</a></div>\n";
	    out << "    <div id=\"btn3\"><a href=\"members.html\">Members</a></div>\n";
	    out << "  </header>\n";
	    out << "  <div class=\"container\"><h2>Available PCs</h2></div>\n";
	    out << "  <table>\n";
	    out << "    <tr>\n";
	    out << "      <th>ID</th>\n";
	    out << "    </tr>\n";
	
	    // Dynamically add rows for all available PCs
	    PCNode* temp = head;
	    while (temp) {
	        if (!temp->isRented) {
	            out << "    <tr>\n";
	            out << "      <td>" << temp->id << "</td>\n";
	            out << "    </tr>\n";
	        }
	        temp = temp->next;
	    }
	
	    out << "  </table>\n";
	    out << "</body>\n";
	    out << "</html>\n";
	
	    out.close();
	}
	
	void saveRentHistoryAsHTML() {
	    ofstream out("RentHistory.html");
	    out << "<!DOCTYPE html>\n";
	    out << "<html lang=\"en\">\n";
	    out << "<head>\n";
	    out << "  <meta charset=\"UTF-8\" />\n";
	    out << "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n";
	    out << "  <title>Rent History</title>\n";
	    out << "  <style>\n";
	    out << "    @import url('https://fonts.googleapis.com/css2?family=monsterrat:wght@400;700&display=swap');\n";
	    out << "    * { box-sizing: border-box; margin: 0; padding: 0; color: white; font-family: monsterrat, sans-serif; }\n";
	    out << "    html { background-color: #333; }\n";
	    out << "    table { border-collapse: collapse; width: 80%; margin: 20px auto; }\n";
	    out << "    header { display: flex; align-items: center; background-color: #000; padding: 0rem 2rem; gap: 2rem; }\n";
	    out << "    header a { text-decoration: none; color: white; }\n";
	    out << "    header img { aspect-ratio: 1/1; height: 7rem; }\n";
	    out << "    #img { margin-right: auto; }\n";
	    out << "    #btn1, #btn2, #btn3, #btn4 { background-color: #423fff; padding: 0.5rem 1rem; border-radius: 0.5rem; }\n";
	    out << "    #btn1:hover, #btn2:hover, #btn4:hover { background-color: #5250ff; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
	    out << "    #btn3 { background-color: #ff3838; }\n";
	    out << "    #btn3:hover { background-color: #ff4848; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
	    out << "    .container { display: flex; justify-content: center; padding: 2rem 0 1rem 0; }\n";
	    out << "    .container h2 { color: #ff3838; }\n";
	    out << "    th, td { border: 1px solid #000; padding: 8px; text-align: left; }\n";
	    out << "    th { background-color: #423fff; }\n";
	    out << "  </style>\n";
	    out << "</head>\n";
	    out << "<body>\n";
	    out << "  <header>\n";
	    out << "    <div id=\"img\">\n";
	    out << "      <a href=\"AllPCs.html\"><img src=\"logoOps.png\" alt=\"Logo\" /></a>\n";
	    out << "    </div>\n";
	    out << "    <div id=\"btn1\"><a href=\"AvailablePCs.html\">Available PC</a></div>\n";
	    out << "    <div id=\"btn2\"><a href=\"RentHistory.html\">Rent History</a></div>\n";
	    out << "    <div id=\"btn4\"><a href=\"Waitlist.html\">Waitlist</a></div>\n";
	    out << "    <div id=\"btn3\"><a href=\"members.html\">Members</a></div>\n";
	    out << "  </header>\n";
	    out << "  <div class=\"container\"><h2>Rent History</h2></div>\n";
	    out << "  <table>\n";
	    out << "    <tr>\n";
	    out << "      <th>PC ID</th>\n";
	    out << "      <th>Renter</th>\n";
	    out << "      <th>Time(hr)</th>\n";
	    out << "    </tr>\n";
	
	    // Dynamically write rent records
	    RentRecord* temp = rentHistoryHead;
	    while (temp) {
	        out << "    <tr>\n";
	        out << "      <td>" << temp->pcID << "</td>\n";
	        out << "      <td>" << temp->renterName << "</td>\n";
	        out << "      <td>" << temp->timeRent << "</td>\n";
	        out << "    </tr>\n";
	        temp = temp->next;
	    }
	
	    out << "  </table>\n";
	    out << "</body>\n";
	    out << "</html>\n";
	
	    out.close();
	}


private:
    PCNode* findPC(int id) {
        PCNode* temp = head;
        while (temp) {
            if (temp->id == id) return temp;
            temp = temp->next;
        }
        return NULL;
    }    
};


// Queue-based Waiting List Menu
void waitingListMenu(queue<Customer>& waitingList) {
    int subChoice;
    PCList shop;
    do {
    	system("cls");
    	shop.header();
    	cout << right << verticalLine << " Waiting List Menu" << setw(81) << verticalLine << endl;
    	cout << verticalLine << setw(99) << verticalLine << endl;
		if (waitingList.empty()) {
            cout << verticalLine << " Waiting list is empty" << setw(77) << verticalLine << endl;
        } else {
            queue<Customer> copy = waitingList;
            while (!copy.empty()) {
                Customer c = copy.front();
                copy.pop();
                cout << left << verticalLine << " " << setw(20) << c.name << setfill(' ') 
					 << setw(3) << " ("  << setfill(' ') << setw(2) << c.timeRequest << setfill(' ')
					 << setw(72) << " hr(s))" << setfill(' ') << verticalLine << endl;
            }
        }
        for(int i = 0; i < 100; i++){
        	if(i == 0){
        		cout << lowerLeftCorner; 	 
			}
			else if(i == 99){
				cout << lowerRightCorner; 
			}
			else{
				cout << horizontalLine;
			}
		}

        cout << "\n\n1. Add Customer to Waiting List\n";
        cout << "2. Remove First in Line\n";
        cout << "0. Back to Main Menu\n";
        cout << "Enter choice: ";
        cin >> subChoice;
        cin.ignore();

        switch (subChoice) {
            case 1: {
                Customer c;
                cout << "Enter Customer Name: ";
                getline(cin, c.name);
                cout << "Enter Requested Time (hours): ";
                cin >> c.timeRequest;
                waitingList.push(c);
                cout << "Customer added to waiting list.\n";
                break;
            }
            case 2:
                if (waitingList.empty()) {
                    cout << "Waiting list is empty.\n";
                } else {
                    Customer c = waitingList.front();
                    waitingList.pop();
                    cout << "Removed: " << c.name << " from waiting list.\n";
                }
                break;
            case 0:
                cout << "Returning to Main Menu...\n";
                break;
            default:
                cout << "Invalid choice.\n";
        }

    } while (subChoice != 0);
}

void saveWaitlistAsHTML(queue<Customer> waitingList) {
    ofstream out("Waitlist.html");
    out << "<!DOCTYPE html>\n";
    out << "<html lang=\"en\">\n";
    out << "<head>\n";
    out << "  <meta charset=\"UTF-8\" />\n";
    out << "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n";
    out << "  <title>Waiting List</title>\n";
    out << "  <style>\n";
    out << "    @import url('https://fonts.googleapis.com/css2?family=monsterrat:wght@400;700&display=swap');\n";
    out << "    * { box-sizing: border-box; margin: 0; padding: 0; color: white; font-family: monsterrat, sans-serif; }\n";
    out << "    html { background-color: #333; }\n";
    out << "    table { border-collapse: collapse; width: 80%; margin: 20px auto; }\n";
    out << "    header { display: flex; align-items: center; background-color: #000; padding: 0rem 2rem; gap: 2rem; }\n";
    out << "    header a { text-decoration: none; color: white; }\n";
    out << "    header img { aspect-ratio: 1/1; height: 7rem; }\n";
    out << "    #img { margin-right: auto; }\n";
    out << "    #btn1, #btn2, #btn3, #btn4 { background-color: #423fff; padding: 0.5rem 1rem; border-radius: 0.5rem; }\n";
    out << "    #btn1:hover, #btn2:hover, #btn4:hover { background-color: #5250ff; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
    out << "    #btn3 { background-color: #ff3838; }\n";
    out << "    #btn3:hover { background-color: #ff4848; transition: background-color 0.3s ease; transform: translate(0, -2px); }\n";
    out << "    .container { display: flex; justify-content: center; padding: 2rem 0 1rem 0; }\n";
    out << "    .container h2 { color: #ff3838; }\n";
    out << "    th, td { border: 1px solid #000; padding: 8px; text-align: left; }\n";
    out << "    th { background-color: #423fff; }\n";
    out << "  </style>\n";
    out << "</head>\n";
    out << "<body>\n";
    out << "  <header>\n";
    out << "    <div id=\"img\">\n";
    out << "      <a href=\"AllPCs.html\"><img src=\"logoOps.png\" alt=\"Logo\" /></a>\n";
    out << "    </div>\n";
    out << "    <div id=\"btn1\"><a href=\"AvailablePCs.html\">Available PC</a></div>\n";
    out << "    <div id=\"btn2\"><a href=\"RentHistory.html\">Rent History</a></div>\n";
    out << "    <div id=\"btn4\"><a href=\"Waitlist.html\">Waitlist</a></div>\n";
    out << "    <div id=\"btn3\"><a href=\"members.html\">Members</a></div>\n";
    out << "  </header>\n";
    out << "  <div class=\"container\"><h2>Waiting List</h2></div>\n";
    out << "  <table>\n";
    out << "    <tr>\n";
    out << "      <th>Customer Name</th>\n";
    out << "      <th>Requested Time (hr)</th>\n";
    out << "    </tr>\n";

    // Add each waiting customer
    while (!waitingList.empty()) {
        Customer c = waitingList.front();
        waitingList.pop();
        out << "    <tr>\n";
        out << "      <td>" << c.name << "</td>\n";
        out << "      <td>" << c.timeRequest << "</td>\n";
        out << "    </tr>\n";
    }

    out << "  </table>\n";
    out << "</body>\n";
    out << "</html>\n";

    out.close();
}



int main() {
    PCList shop;
    queue<Customer> waitingList;
    int choice;
    string usernameInput, passwordInput;
    string username = "1";
    string password = "2";
    
    do{ 
   	    system("cls");
    	shop.header();
    	
    	for(int i = 0; i < 100; i++){
    		if(i == 0 || i == 99){
    			cout << right << verticalLine;
			}else{
				cout << " ";
			}
		}
    	cout << '\n' << verticalLine << setw(55) << "Enter username : ";
    	getline(cin, usernameInput);
    	cout << verticalLine << setw(55) << "Enter password : ";
    	getline(cin, passwordInput);
		for(int i = 0; i < 2; i++){
			if(i == 0){
				for(int j = 0; j < 100; j++){
					if(j == 0 || j == 99){
		    			cout << verticalLine;
					}else{
						cout << " ";
					}
				} 
			}
			if(i == 1){
				for(int j = 0; j < 100; j++){
					if(j == 0){
		    			cout << lowerLeftCorner;
					}
					else if(j == 99){
						cout << lowerRightCorner;
					}
					else{
						cout << horizontalLine;
					}
				} 
			}
    		cout << endl;
		}
    	cin.ignore();
		  	
    	if(username == usernameInput && password == passwordInput){
		    do {	
		        system("cls");
		        shop.header();
		        shop.displayGrid();
		
		        cout << "[1] Add new Information (Rent PC)\n";
		        cout << "[2] Extend Time\n";
		        cout << "[3] Release PC\n";
		        cout << "[4] Search Computer Number (1-15)\n";
		        cout << "[5] Show Available Computers Only\n";
		        cout << "[6] Show Active User Computers Only\n";
		        cout << "[7] View All Renters for the Day\n";
		        cout << "[8] Waiting List (Queue)\n";
		        cout << "[9] Exit\n";
		        cout << "Enter choice: ";
		        cin >> choice;
		        cin.ignore();
		
		        switch (choice) {
		            case 1: {
		                int id, time;
		                string name;
		                cout << "Enter PC ID (1-15): ";
		                cin >> id;
		                cin.ignore();
		                cout << "Enter Renter Name: ";
		                getline(cin, name);
		                cout << "Enter Time Rent (hours): ";
		                cin >> time;
		                shop.addInformation(id, name, time);
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		            }
		
		            case 2: {
		                int id, extra;
		                cout << "Enter PC ID to extend time: ";
		                cin >> id;
		                cout << "Enter additional hours: ";
		                cin >> extra;
		                shop.extendTime(id, extra);
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		            }
		
		            case 3: {
		                int id;
		                cout << "Enter PC ID to release: ";
		                cin >> id;
		                shop.releasePC(id);
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		            }
		
		            case 4: {
		                int id;
		                cout << "Enter PC ID to search: ";
		                cin >> id;
		                shop.searchPC(id);
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		            }
		
		            case 5:
		                system("cls");
		                shop.showAvailable();
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		
		            case 6:
		                shop.showActive();
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		
		            case 7:
		                shop.showRentHistory();
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		
		            case 8:
		            	system("cls");
		            	
		                waitingListMenu(waitingList);
		                cout << "Press ENTER to continue...";
		                cin.ignore();
		                break;
		
		            case 9:
					    cout << "\nSaving HTML files and exiting...\n";
					    shop.saveAllPCsAsHTML();
					    shop.saveAvailablePCsAsHTML();
					    shop.saveRentHistoryAsHTML();
					    saveWaitlistAsHTML(waitingList);
					    cin.ignore();
					    break;

		            default:
		                cout << "Invalid choice. Try again.\n";
		        }
		    } while (choice != 9);    		
		}
	} while (true);
    return 0;
}

