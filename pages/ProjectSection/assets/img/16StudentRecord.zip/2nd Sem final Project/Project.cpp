#include <iostream>
#include <iomanip>
#include <cstdlib> // For system("cls")
#include <unistd.h> // sleep()
#include <cctype> //Validation
#include <fstream> // For file handling
#include <ctime>  // Required for date and time

#define RESET "\033[0m"
#define GREEN "\033[32m"
#define RED "\033[31m"
#define CYAN "\033[36m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"

#define logoValue 153
#define lineValue 100
#define verticalLineValue 186
#define horizontalLineValue 205
#define upperRightCornerValue 187
#define upperLeftCornerValue 201
#define lowerRightCornerValue 188
#define lowerLeftCornerValue 200
#define threeRightCornerValue 185
#define threeLeftCornerValue 204
#define centerCrossValue 206
#define threeDownCornerValue 203
#define threeUpCornerValue 202

using namespace std;

struct Node {
    string name;
    string phoneNo;
    string address;
    Node* next;
};

Node* topHead = NULL; 
Node* bottomHead = NULL; 

void display();
void addRecord(bool atBeginning);
void deleteRecord(bool fromBeginning);
void displayHeader();
void openSpace();
void lowerLine();
void displayAccount(string &storedUsername, string &storedPassword);
void displayInformation(string &storedUsername);
void printToFile(string &storedUsername);
void profile();
void innerOpenLine();

int main() {
    int choice;
    char choiceMenu;
    string username;
    string  password;
    string storedUsername = "1";
    string  storedPassword = "1";
    
    char verticalLine = verticalLineValue;
    char horizontalLine = horizontalLineValue;
    char upperRightCorner = upperRightCornerValue;
	char upperLeftCorner = upperLeftCornerValue;
	char lowerRightCorner = lowerRightCornerValue;
	char lowerLeftCorner = lowerLeftCornerValue;
	char threeRightCorner = threeRightCornerValue;
	char threeLeftCorner = threeLeftCornerValue;
	char box = 254;
    
    do {
	    displayHeader();
	    openSpace();
	    openSpace();
	
	    cout << verticalLine << setw(50) << "Username : ";
	    getline(cin, username);  	
	    cout << verticalLine << setw(50) << "Password : ";
	    getline(cin, password);
	
	    openSpace();
	    openSpace();
		lowerLine();
		
		sleep(1);
		cout << "Verifying Credentials, please wait : " GREEN << box;
		sleep(1);
		cout << " " << box;
		sleep(1);
		cout << " " << box << RESET << endl;
		
		
	    if(username == storedUsername && password == storedPassword) { // Fixed comparison
	        
	        cout << '\a';
	        cout << "Log-in Successful!";
	        sleep(1);
	        sleep(1);
	
	        do {
	        	system("cls");
	        	displayHeader();
	        	cout << verticalLine << BLUE << " Home Page" << RESET << setw(91) << verticalLine << '\n';
	        	openSpace();
	            cout << verticalLine << setw(52) << "[1] Account" << setw(49) << verticalLine << '\n';
	            cout << verticalLine << setw(56) << "[2] Information" << setw(45) << verticalLine << '\n';
	            cout << verticalLine << setw(49) << "[x] Exit" << setw(52) << verticalLine << '\n';
	            openSpace();
	            lowerLine();
	            cout << "Input: ";
	            cin >> choiceMenu;
	            cin.ignore(); // Prevent input skipping
	
	            switch(choiceMenu) {
	                case '1': 
	                    system("cls");
	                    displayAccount(storedUsername, storedPassword);
	                    break;
	                case '2': 
	                    system("cls");
	                    do {
	                    	displayHeader();
	                    	cout.unsetf(ios::left);
	                    	cout << left << verticalLine << BLUE << " Home Page - Information" << setw(80) << setfill(' ') << RESET << verticalLine << endl;
	                    	openSpace();
					    	cout << left << verticalLine << setw(1) << " Welcome back, sir " << YELLOW << storedUsername << RESET << setw(81 - storedUsername.length()) << setfill(' ') << "!" << verticalLine << "\n";
							cout.unsetf(ios::left);
							openSpace();
							openSpace();
							cout << verticalLine ;
					        display();
					        cout << "\nOptions:" << endl;
					        cout << "1. Add Record" << endl;
					        cout << "2. Delete Record" << endl;
					        cout << "3. Exit" << endl;
					        cout << "4. Print and Exit" << endl;
					        cout << "Enter choice: ";
					        cin >> choice;
					
					        switch (choice) {
					            case 1: {
					                int addChoice;
					                cout << "\nWhere do you want to add the record?" << endl;
					                cout << "1. Beginning" << endl;
					                cout << "2. End" << endl;
					                cout << "Enter choice: ";
					                cin >> addChoice;
					                addRecord(addChoice == 1);
					                system("cls");
					                break;
					            }
					            case 2: {
					                int deleteChoice;
					                cout << "\nWhere do you want to delete the record?" << endl;
					                cout << "1. Beginning" << endl;
					                cout << "2. End" << endl;
					                cout << "Enter choice: ";
					                cin >> deleteChoice;
					                deleteRecord(deleteChoice == 1);
					                system("cls");
					                break;
					            }
					            case 3:
					                cout << "Exiting program..." << endl;
					                break;
					            case 4:
					                printToFile(storedUsername); // Calls the function to save and exit
					                return 0;
					            default:
					                cout << "Invalid choice. Please try again." << endl;
					                system("cls");
					        }
					    } while (choice != 3);
	                    break;
	                case 'x': 
	                case 'X': 
	                    cout << "Logging out...\n";
	                    sleep(1);
	                    return 0; // Exit program
	                default: 
	                    cout << "Invalid input!\n";
	            }
	        } while(true);
	    }
	
	    cout << "Incorrect Username or Password!";
		
		cout << '\a';
	    sleep(1);
	    sleep(1);
	    system("cls");

	} while(true);

    return 0;
}

void display() {
	
	char verticalLine = verticalLineValue;
    char horizontalLine = horizontalLineValue;
    char upperRightCorner = upperRightCornerValue;
	char upperLeftCorner = upperLeftCornerValue;
	char lowerRightCorner = lowerRightCornerValue;
	char lowerLeftCorner = lowerLeftCornerValue;
	char threeRightCorner = threeRightCornerValue;
	char threeLeftCorner = threeLeftCornerValue;
	char centerCross = centerCrossValue;
	char threeDownCorner = threeDownCornerValue;
	char threeUpCorner = threeUpCornerValue;
	
	cout.unsetf(ios::left);
	
	cout << upperLeftCorner;
	
	//#define centerCrossValue 206
	//#define threeDownCornerValue 203
	//#define threeUpCornerValue 202
	
	for(int i = 0; i < 99; i++){
		if(i == 98){
    		cout << upperRightCorner;
		}else if(i == 30 || i == 65){
			cout << threeDownCorner;
		}else{
			cout << horizontalLine;
		}
	}
	
    cout << verticalLine << "\n" << verticalLine << verticalLine << left << GREEN << setw(30) << "NAME" << RESET << verticalLine << YELLOW << setw(34) << setfill(' ') << " PHONE NUMBER" << RESET << verticalLine << CYAN << setw(32) << setfill(' ')  << " ADDRESS" << RESET << verticalLine << verticalLine << endl;
    
    innerOpenLine();
	
	cout << verticalLine << endl;

    Node* temp = topHead;
    while (temp != NULL) {
        cout << left << verticalLine << verticalLine << setw(30) << temp->name << verticalLine <<  " " << setw(33) << setfill(' ')  << temp->phoneNo << verticalLine << " " << setw(31) << setfill(' ') << temp->address << verticalLine << verticalLine << endl;
        temp = temp->next;
        innerOpenLine();
        cout << verticalLine;
        cout << endl;
    }
    	
    cout << left << verticalLine << verticalLine << setw(30) <<  "Lee, Ray" << verticalLine << setw(34) << setfill(' ') << " 09157071866" << verticalLine << setw(32) << setfill(' ') << " Caloocan City" << verticalLine << verticalLine << endl;
	innerOpenLine();
	cout << verticalLine << "\n" << left << verticalLine << verticalLine << setw(30) << "Ogalesco, Araand" << verticalLine << setw(34) << setfill(' ') << " 3623214" << verticalLine << setw(32) << setfill(' ') << " Quezon City" << verticalLine << verticalLine << endl;
    innerOpenLine();
	cout << verticalLine << "\n" << left << verticalLine << verticalLine << setw(30) << "Lao, Ronald" << verticalLine << setw(34) << setfill(' ') << " 09229733699" << verticalLine << setw(32) << setfill(' ') << " Pasig City" << verticalLine << verticalLine << endl;
    innerOpenLine();
	cout << verticalLine << "\n" << left << verticalLine << verticalLine << setw(30) << "Lizardo, Ivan" << verticalLine << setw(34) << setfill(' ') << " 09229733699" << verticalLine << setw(32) << setfill(' ') << " Echo Valley" << verticalLine << verticalLine << endl;
    

    temp = bottomHead;
    while (temp != NULL) {
    	innerOpenLine();
        cout << verticalLine;
        cout << endl;
        cout << left << verticalLine << verticalLine << setw(30) << temp->name << verticalLine <<  " " << setw(33) << setfill(' ')  << temp->phoneNo << verticalLine << " " << setw(31) << setfill(' ') << temp->address << verticalLine << verticalLine << endl;
        temp = temp->next;
    }
    
    cout << verticalLine << lowerLeftCorner;
    
    for(int i = 0; i < 99; i++){
    	if(i == 98){
    		cout << lowerRightCorner;
		}else if(i == 30 || i == 65){
			cout << threeUpCorner;
		}else{
			cout << horizontalLine;
		}	
	}
	cout << verticalLine << endl;
	openSpace();
	lowerLine();
    
    cout.unsetf(ios::left);
}

void addRecord(bool atBeginning) {
	
    string name, phoneNo, address;
    cout << "Enter name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter phone number: ";
    getline(cin, phoneNo);
    cout << "Enter address: ";
    getline(cin, address);

    Node* newNode = new Node{name, phoneNo, address, NULL};

    if (atBeginning) {
        newNode->next = topHead;
        topHead = newNode; 
    } else {
        if (bottomHead == NULL) {
            bottomHead = newNode;
        } else {
            Node* temp = bottomHead;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newNode; 
        }
    }

    cout << "Record added successfully!" << endl;
}

void deleteRecord(bool fromBeginning) {
    if (fromBeginning) {
        if (topHead == NULL) {
            cout << "No records at the top to delete!" << endl;
            return;
        }
        Node* temp = topHead;
        topHead = topHead->next;
        delete temp;
        cout << "Record deleted from the beginning!" << endl;
    } else {
        if (bottomHead == NULL) {
            cout << "No records at the bottom to delete!" << endl;
            return;
        }
        Node* temp = bottomHead;
        Node* prev = NULL;

        if (temp->next == NULL) { 
            delete temp;
            bottomHead = NULL;
        } else {
            while (temp->next != NULL) { 
                prev = temp;
                temp = temp->next;
            }
            prev->next = NULL;
            delete temp;
        }

        cout << "Record deleted from the end!" << endl;
    }
}

void displayHeader(){
	
	char verticalLine = verticalLineValue;
    char horizontalLine = horizontalLineValue;
    char upperRightCorner = upperRightCornerValue;
	char upperLeftCorner = upperLeftCornerValue;
	char lowerRightCorner = lowerRightCornerValue;
	char lowerLeftCorner = lowerLeftCornerValue;
	char threeRightCorner = threeRightCornerValue;
	char threeLeftCorner = threeLeftCornerValue;
	char logo = logoValue;
	
	cout << upperLeftCorner;
	for(int i = 0; i < lineValue; i++){	
		cout << horizontalLine;
	}
	cout << upperRightCorner << '\n';
	for(int i = 0; i < lineValue; i++){
		if(i == 0 || i == lineValue - 26){
			cout << verticalLine;
		}
		if(i == 1){
			cout << logo;
		}
		if(i == lineValue/2 - 17){
			cout << "FEU TECH Information sheet";	
		}else if(i > lineValue - 26){
			cout << "";
		}else{
			cout << " ";
		}
	}
	cout << '\n';
	cout << threeLeftCorner;
	for(int i = 0; i < lineValue; i++){
		
		cout << horizontalLine;
	}
	cout << threeRightCorner << '\n';
}

void openSpace(){
	char verticalLine = verticalLineValue;
	
	for(int i = 0; i < lineValue + 2; i++){
		if(i == 0 || i == lineValue + 1){
			cout << verticalLine;
		}else{
			cout << " ";
		}
	}
	cout << '\n';
}

void lowerLine(){
	char horizontalLine = horizontalLineValue;
	char lowerLeftCorner = lowerLeftCornerValue;
	char lowerRightCorner = lowerRightCornerValue;
	
	cout << lowerLeftCorner;
	for(int i = 0; i < lineValue; i++){
		cout << horizontalLine;
	}
	cout << lowerRightCorner << '\n';
}

void displayAccount(string &storedUsername, string &storedPassword){
	
	char choice;
	char verticalLine = verticalLineValue;
	char horizontalLine = horizontalLineValue;
	char upperLeftCorner = upperLeftCornerValue;
	char upperRightCorner = upperRightCornerValue;
	char lowerLeftCorner = lowerLeftCornerValue;
	char lowerRightCorner = lowerRightCornerValue;
	char profile = 219;
	char profileLight = 233;
	char profileThin = 176;
	char half = 220;
	char upper = 223;
	char leftHalf = 221;
	char rightHalf = 222;
	
	do{	
		system ("cls");
		displayHeader();
		cout << verticalLine << BLUE << " Home Page - Account Profile" << RESET << setw(73) << verticalLine << '\n';
		openSpace();
		for(int i = 0; i < lineValue; i++){
			if(i == 0){
				cout << verticalLine;
			}else if(i == 1){
				cout << upperLeftCorner;
			}else if(i < 40 && i > 1){
				cout << horizontalLine;
			}else if(i == 41){
				cout << upperRightCorner;
			}
		}
		cout << setw(61) << verticalLine;
		cout << '\n';
		cout << verticalLine << verticalLine << setw(14) << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << profileThin << setw(13) << verticalLine; cout << setw(61) << verticalLine  << '\n';
		cout << verticalLine << verticalLine << setw(14) << profileThin << YELLOW << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << RESET << profileThin << setw(13) << verticalLine; cout << setw(61) << verticalLine  << '\n';
		cout << verticalLine << verticalLine << setw(18) << YELLOW << profile << profile << RESET << profile  << BLUE << profile << YELLOW << profile << profile << profile << profile << BLUE << profile << RESET << profile << YELLOW << profile << profile << profile << RESET << setw(13) << verticalLine << setw(33) << "NAME     : IVAN MARK LIZARDO" << setw(28) << verticalLine << '\n';
		cout << verticalLine << verticalLine << setw(18) << YELLOW << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << RESET << setw(13) << verticalLine << setw(18) << "AGE      : 20"  << setw(43) << verticalLine << '\n';
		cout << verticalLine << verticalLine << setw(18) << YELLOW << profile << profile << profile << profile << profile << profile << profile << profile << upper << profile << profile << profile << profile << RESET << setw(13) << verticalLine << setw(20) << "SEX      : MALE" << setw(41) << verticalLine << '\n';
		cout << verticalLine << verticalLine << setw(18) << YELLOW << profile << profile << profile << profile << profile << half << half << half << profile << profile << profile << profile << profile << RESET << setw(13) << verticalLine << setw(35) << "POSITION : Information Manager" << setw(26) << verticalLine << '\n';
		cout << verticalLine << verticalLine << setw(23) << YELLOW << profile << profile << profile  << setw(21) << RESET << verticalLine; cout << setw(61) << verticalLine  << '\n';
		cout << verticalLine << verticalLine << setw(15) << CYAN << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << setw(13) << RESET << verticalLine; cout << setw(61) << verticalLine  << '\n';
		cout << verticalLine << verticalLine << setw(15) << CYAN << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << setw(13) << RESET << verticalLine << left << "     USERNAME : " << setw(44) << setfill(' ') << storedUsername << setfill(' ') << verticalLine << '\n';
		cout << verticalLine << verticalLine << setw(15) << CYAN << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << profile << setw(13) << RESET << verticalLine << left << "     PASSWORD : " << setw(44) << setfill(' ') << storedPassword << setfill(' ') << verticalLine << '\n';
		cout.unsetf(ios::left);
		cout << verticalLine << verticalLine << setw(15) << CYAN << profile << profile << profile << profile << rightHalf << profile << profile << profile << profile << profile << profile << profile << profile << profile << leftHalf << profile << profile << profile << profile << setw(13) << RESET << verticalLine; cout << setw(61) << verticalLine  << '\n';
		cout << verticalLine << verticalLine << setw(15) << CYAN << profile << profile << profile << profile << rightHalf << profile << profile << profile << profile << profile << profile << profile << profile << profile << leftHalf << profile << profile << profile << profile << setw(13) << RESET << verticalLine; cout << setw(61) << verticalLine  << '\n';
		cout << verticalLine << verticalLine << setw(15) << CYAN << profile << profile << profile << profile << rightHalf << profile << profile << profile << profile << profile << profile << profile << profile << profile << leftHalf << profile << profile << profile << profile << setw(13) << RESET << verticalLine; cout << setw(61) << verticalLine  << '\n';
		cout << verticalLine << verticalLine << setw(15) << CYAN << profile << profile << profile << profile << rightHalf << profile << profile << profile << profile << profile << profile << profile << profile << profile << leftHalf << profile << profile << profile << profile << setw(13) << RESET << verticalLine; cout << setw(61) << verticalLine  << '\n';
		for(int i = 0; i < lineValue; i++){
			if(i == 0){
				cout << verticalLine;
			}else if(i == 1){
				cout << lowerLeftCorner;
			}else if(i < 40 && i > 1){
				cout << horizontalLine;
			}else if(i == 41){
				cout << lowerRightCorner;
			}
		}
		cout << setw(61) << verticalLine;
		cout << '\n';
		lowerLine();
		
		cout << "[1] Change Username \n";
		cout << "[2] Change Password \n";
		cout << "[x] back \n";
		cout << "Input : ";
		cin >> choice;
		cin.ignore();
		
		switch(choice){
			case '1' : cout << "Enter new Username : ";
					   getline(cin, storedUsername);
					   break;
			case '2' : cout << "Enter new Password : ";
					   getline(cin, storedPassword);
					   break;
			case 'X' :
			case 'x' : break;
			default : cout << "Invalid Input!";
		}				
	}while (choice != 'x');	
}

void printToFile(string &storedUsername) {
    ofstream file("database1.doc"); 

    if (!file) {
        cerr << "Error opening file!" << endl;
        return;
    }
    
    // Get current date
    time_t now = time(0);
    tm *ltm = localtime(&now);
    char datePrinted[20];
    strftime(datePrinted, sizeof(datePrinted), "%Y-%m-%d", ltm); // Format: YYYY-MM-DD

    // HTML Header and Styling
    file << "<html><head><title>FEU TECH Information Sheet</title>\n";
    file << "<style>\n";
    file << "body { font-family: Arial, sans-serif; text-align: center; }\n";
    
    // Title Container (Flexbox for Image + Title Alignment)
    file << ".title-container { display: flex; align-items: center; justify-content: center; gap: 15px; }\n";
    file << ".title-container img { width: 80px; height: 80px; }\n";  // Logo size
    file << ".title-container h2 { margin: 0; }\n";  

    // Table Styling
    file << "table { width: 80%; margin: auto; border-collapse: collapse; }\n";
    file << "th, td { border: 1px solid black; padding: 8px; text-align: center; }\n";
    file << "th { background-color: #FFC000; color: black; }\n"; 
    file << "td { background-color: #f9f9f9; }\n"; 
    file << "</style>\n</head><body>\n";

    
    file << "<div class='title-container'>\n";
    file << "<img src='FEUTECH.png' alt='Company Logo'>";  
    file << "<h2>FEU TECH INFORMATION SHEET</h2>\n";
    file << "</div>\n";

    // Username and Date
    file << "<p><b>Username:</b> " << storedUsername << " &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; <b>Date Printed:</b> " << datePrinted << "</p>\n";

    // Table Header
    file << "<table>\n";
    file << "<tr><th>NAME</th><th>PHONE NUMBER</th><th>ADDRESS</th></tr>\n";

    // Writing data from topHead
    Node* temp = topHead;
    while (temp != NULL) {
        file << "<tr><td>" << temp->name << "</td><td>" << temp->phoneNo << "</td><td>" << temp->address << "</td></tr>\n";
        temp = temp->next;
    }
    
    // Writing hardcoded data
    file << "<tr><td>Lee, Ray</td><td>09157071866</td><td>Caloocan</td></tr>\n";
    file << "<tr><td>Ogalesco, Araand</td><td>3623214</td><td>Quezon City</td></tr>\n";
    file << "<tr><td>Lao, Ronald</td><td>09229733699</td><td>Pasig City</td></tr>\n";
    file << "<tr><td>Lizardo, Ivan</td><td>09229733699</td><td>Echo Valley</td></tr>\n";

    // Writing data from bottomHead
    temp = bottomHead;
    while (temp != NULL) {
        file << "<tr><td>" << temp->name << "</td><td>" << temp->phoneNo << "</td><td>" << temp->address << "</td></tr>\n";
        temp = temp->next;
    }

    // Closing Table
    file << "</table>\n";

    // Information Manager Signature
    file << "<br><br><p><b>Ivan Mark Lizardo</b><br>_______________________<br>Information Manager</p>\n";

    // Close HTML
    file << "</body></html>\n";
    
    file.close(); // Close the file
    cout << "Information printed to database1.doc successfully!" << endl;
}


void innerOpenLine(){
	
	char threeLeftCorner = threeLeftCornerValue;
	char threeRightCorner = threeRightCornerValue;
	char horizontalLine = horizontalLineValue;
	char verticalLine = verticalLineValue;
	char centerCross = centerCrossValue;
	
	cout << verticalLine << threeLeftCorner;
    
    for(int i = 0; i < 99; i++){
    	if(i == 98){
    		cout << threeRightCorner;
		}else if(i == 30 || i == 65){
			cout << centerCross;
		}else{
			cout << horizontalLine;
		}	
	}
	
}


