//Queue
#include <iostream>
#include <unistd.h>
#include <cstdlib>
#include <iomanip>
#define RESET "\033[0m"
#define GREEN "\033[32m"
#define RED "\033[31m"
#define YELLOW "\033[33m"
#define verticalValue 186
#define horizontalValue 205
#define upperRightValue 187
#define upperLeftValue 201
#define lowerRightValue 188
#define lowerLeftValue 200
#define tiresValue 177
#define threeCornerRightValue 185
using namespace std;

class Node{
    public:
        int num;
        Node* next;
};

typedef Node* nodePtr;

void AddCar(nodePtr* head, nodePtr* tail){
    int size = 0;
    nodePtr newNode = new Node();
    newNode->next = NULL;

    cout << "Enter a value : ";
    cin >> newNode->num;

    if (*head == NULL) {
        *head = *tail = newNode;
    } else {
        (*tail)->next = newNode;
        *tail = newNode;
    }
    size++;
}

void RemoveCar(nodePtr* head){ 
    nodePtr temp = *head;
    *head = (*head)->next;
    delete temp;
}

void display(nodePtr head, int &size){
	char darkShade = 178;
	char verticalLine = verticalValue;
	char carVerticalLine = 179;
	char carHorizontalLine = 196;
	char carUpperRightLine = 191;
	char carUpperLeftLine = 218;
	char carLowerRightLine = 217;
	char carLowerLeftLine = 192;
	char carHood = 194;
	char tire = 177;
	char rearLight = 223;
	char light = 220;
	char box = 254;
	char close = 247;

    nodePtr temp = head;
    while(temp != NULL){
    	cout << "  " << darkShade << setw(14) << verticalLine << setw(14) << darkShade << endl;
		cout << "  " << darkShade << "   ";
		for(int i = 0; i <= 20; i++){
			if(i == 0){
				cout << carUpperLeftLine;
			}else if((i >= 2 && i <= 5) || (i >= 15 && i <= 18)){
				cout << YELLOW << light << RESET;
			}else if(i == 20){
				cout << carUpperRightLine;
			}else{
				cout << carHorizontalLine;	
			}	
		}	
		cout << "   " << darkShade << endl;
		cout << "  " << darkShade << "   ";
		for(int i = 0; i <= 20; i++){ // <= hallow
			if(i == 0 || i == 20){
				cout << carVerticalLine;
			}else if(i == 20){
				cout << carVerticalLine;
			}else{
				cout << " ";
			}
		}
		cout << "   " << darkShade << endl;
		cout << "  " << darkShade << "   ";
		for(int i = 0; i <= 20; i++){
			if(i == 0 || i == 20){
				cout << tire;
			}else if(i == 20){
				cout << carVerticalLine;
			}else{
				cout << " ";
			}
		}
		cout << "   " << darkShade << endl;
		cout << "  " << darkShade << "   ";
		for(int i = 0; i <= 20; i++){ // <= hallow
			if(i == 0 || i == 20){
				cout << carVerticalLine;
			}else if(i == 20){
				cout << carVerticalLine;
			}else{
				cout << "_";
			}
		}
		cout << "   " << darkShade << endl;
		cout << "  " << darkShade << "   ";
		for(int i = 0; i <= 20; i++){ // <= hallow
			if(i == 0){
				cout << "/";
			}else if(i == 20){
				cout << "\\";
			}else{
				cout << " ";
			}
		}
		cout << "   " << darkShade << endl;
		cout << "  " << darkShade << "  ";
		for(int i = 0; i <= 22; i++){ // <= hallow
			if(i == 0 || i == 22){
				cout << carVerticalLine;
			}else{
				cout << "-";
			}
		}
		for(int i = 0; i < 7; i++){
			cout << "  " << darkShade << endl;
			cout << "  " << darkShade << "  ";
			if(i == 4){
				cout << carVerticalLine << setw(13) << "Label : " << temp->num << setw(6) << carVerticalLine; //<-- LABEL
			}else{
				for(int i = 0; i <= 22; i++){ // <= hallow
					if(i == 0 || i == 22){
						cout << carVerticalLine;
					}else{
						cout << " ";
					}
				}
			}		
		}
		cout << "  " << darkShade << endl;
		cout << "  " << darkShade << "  ";
		for(int i = 0; i <= 22; i++){ // <= hallow
			if(i == 0 || i == 22){
				cout << tire;
			}else{
				cout << " ";
			}
		}
		cout << "  " << darkShade << endl;
		cout << "  " << darkShade << "  ";
		for(int i = 0; i <= 22; i++){ // <= hallow
			if(i == 0 ){
				cout << carLowerLeftLine;
			}else if(i == 22){
				cout << carLowerRightLine;
			}else if(i == 1 || i == 21){
				cout << carHood;
			}else{
				cout << carHorizontalLine;
			}
		}
		cout << "  " << darkShade << endl;
		cout << "  " << darkShade << "   ";
		for(int i = 0; i <= 20; i++){ // <= hallow
			if(i == 0 ){
				cout << carLowerLeftLine;
			}else if(i == 20){
				cout << carLowerRightLine;
			}else if((i >= 1 && i <= 4) || (i >= 16 && i <= 19)){
				cout << RED << rearLight << RESET;
			}else{
				cout << carHorizontalLine;
			}
		}  
		cout << "   ";
    	if(size >= 0 && size <= 2){
			cout << GREEN << box << RESET;
		}else if(size >= 3 && size <= 4){
			cout << YELLOW << box << RESET;
		}else if(size == 5){
			cout << RED << box << RESET;
		}	
		cout << endl;
		temp = temp->next;          
    }
    cout << "  ";
    if(size == 5){
		for(int i = 0; i < 29; i++){
			cout << close;
		}
	}
}

void displaySign(nodePtr head, int &size){
	char verticalLine = verticalValue;
	char horizontalLine = horizontalValue;
	char upperLeftLine = upperLeftValue;
	char upperRightLine = upperRightValue;
	char lowerLeftLine = lowerLeftValue;
	char lowerRightLine = lowerRightValue;
	char threeCornerRightLine = threeCornerRightValue;
	char darkShade = 178;
	char box = 254;
	cout << " ";
	for(int i = 0; i <= 30; i++){
		if(i == 0){
			cout << upperLeftLine;
		}else if(i == 30){
			cout << upperRightLine << endl;
		}else{
			cout << horizontalLine;	
		}	
	}
	cout << horizontalLine << threeCornerRightLine << setw(18) << "CAR WASH" << setw(14);
	if(size >= 0 && size <= 2){
		cout << GREEN << box << RESET;
	}else if(size >= 3 && size <= 4){
		cout << YELLOW << box << RESET;
	}else if(size == 5){
		cout << RED << box << RESET;
	}
	
	cout << " " <<verticalLine << endl;
	cout << " ";
	for(int i = 0; i <= 30; i++){
		if(i == 0){
			cout << lowerLeftLine;
		}else if(i == 30){
			cout << lowerRightLine;
		}else{
			cout << horizontalLine;	
		}	
	}
	if(head == NULL){
		cout << endl;
		for (int i = 0; i < 14; i++){
			if (i % 2 == 1) {  // Check if 'i' is odd
				cout << "  " << darkShade << setw(14) << verticalLine << setw(14) << darkShade << endl;
			}else{
				cout << "  " << darkShade << setw(28) << darkShade << endl;
			}
		}
	}
	
}

void ClearAllCars(nodePtr* head) {
    nodePtr temp;
    while (*head != NULL) {
        temp = *head;
        *head = (*head)->next;
        delete temp;
    }
}

int main(){
    int choice;
    int size = 0;
    int max = 5;
    nodePtr head = NULL;
    nodePtr tail = NULL; // <-- added tail

    do{
    	
    	displaySign(head, size);
    	cout << endl;
        display(head, size);
        cout << "\n\nMenu\n";
        cout << "[1] Add Car\n";
        cout << "[2] Car Wash\n";
        cout << "[3] Reveal Pending Car\n";
        cout << "[4] Exit\n";
        cout << "Choice : ";
        cin >> choice;
        switch(choice){
            case 1: 
					if(size < max){
						AddCar(&head, &tail); size++;
					}else{
						cout << "Car Wash is FULL\n";
					}
					 break; //Add car
            case 2:
                    if (head == NULL) {
                        break;
                    } else {
                        RemoveCar(&head);
                        size--;
                    }
                    break;
            case 3: cout << "Car size is " << size << '\n'; break; //Check car Size
            case 4:  ClearAllCars(&head); cout << "SAFELY DELETED\n"; break; //Exit program
            default: cout << "Invalid Input!\n";
        }
        system("pause");
        system("cls");
    } while(choice != 4);
}
